1. Checkout repository
2. Open in Visual Studio and check under ToDo.Api project appsettings.json "DefaultConnection" value - check if Server is pointing to your SQL server instance location
3. Run Update-Database in package manager console
4. Build and run project
